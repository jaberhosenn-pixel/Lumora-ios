#!/usr/bin/env bash
# Builds an UNSIGNED Lumora.ipa on a macOS runner (no Apple Developer account needed).
# The IPA must be re-signed on your device with AltStore / Sideloadly (free Apple ID).
set -eo pipefail

{
  flutter --version
  flutter create --platforms=ios --project-name lumora --org com.lumora .

  P=ios/Runner/Info.plist
  PB=/usr/libexec/PlistBuddy
  add() { $PB -c "Add :$1 $2 $3" "$P" 2>/dev/null || $PB -c "Set :$1 $3" "$P"; }

  add CFBundleDisplayName string "Lumora"
  add CFBundleName string "Lumora"
  add NSMicrophoneUsageDescription string "Lumora uses the microphone for voice input."
  add NSSpeechRecognitionUsageDescription string "Lumora uses speech recognition to turn your voice into text."
  add NSPhotoLibraryUsageDescription string "Lumora needs access to your photos so you can attach images."
  add NSCameraUsageDescription string "Lumora needs the camera so you can attach photos."
  # Android build uses usesCleartextTraffic=true; iOS equivalent (for http:// MCP/API servers):
  $PB -c "Add :NSAppTransportSecurity dict" "$P" 2>/dev/null || true
  $PB -c "Add :NSAppTransportSecurity:NSAllowsArbitraryLoads bool true" "$P" 2>/dev/null || true

  flutter pub get
  dart run flutter_launcher_icons -f ci/flutter_launcher_icons_ios.yaml

  flutter build ios --release --no-codesign

  rm -rf build/Payload build/Lumora.ipa
  mkdir -p build/Payload
  cp -R build/ios/iphoneos/Runner.app build/Payload/
  (cd build && zip -qry Lumora.ipa Payload)
  ls -lh build/Lumora.ipa
} 2>&1 | tee build.log
