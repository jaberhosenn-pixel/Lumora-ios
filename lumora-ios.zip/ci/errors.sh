#!/usr/bin/env bash
grep -A12 -m1 "What went wrong" build.log | while IFS= read -r l; do echo "::error::${l:0:300}"; done || true
grep -nE "error:|Error:|version solving|Because " build.log | head -n 8 | while IFS= read -r l; do echo "::error::${l:0:300}"; done || true
{ echo '```'; tail -n 40 build.log; echo '```'; } >> "$GITHUB_STEP_SUMMARY"
