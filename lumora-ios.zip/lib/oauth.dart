import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter_web_auth_2/flutter_web_auth_2.dart';
import 'package:http/http.dart' as http;
import 'store.dart';

/// OAuth 2.1 (PKCE + dynamic client registration) for MCP servers. No backend needed.
class OAuth {
  static const redirect = 'lumora://oauth';

  static String _rand(int n) {
    final r = Random.secure();
    return base64UrlEncode(List.generate(n, (_) => r.nextInt(256)))
        .replaceAll('=', '');
  }

  static Future<Map<String, dynamic>> _json(String url) async {
    final r = await http.get(Uri.parse(url),
        headers: {'Accept': 'application/json'}).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode} for $url');
    return Map<String, dynamic>.from(jsonDecode(utf8.decode(r.bodyBytes)));
  }

  static Map<String, dynamic> _pack(Map t, String tokenEp, String clientId,
          [String? oldRefresh]) =>
      {
        'access': t['access_token'],
        'refresh': t['refresh_token'] ?? oldRefresh,
        'exp': DateTime.now().millisecondsSinceEpoch ~/ 1000 +
            ((t['expires_in'] ?? 3600) as num).toInt() -
            60,
        'tokenEp': tokenEp,
        'cid': clientId,
      };

  static Future<Map<String, dynamic>> login(String mcpUrl) async {
    final u = Uri.parse(mcpUrl);
    final origin = u.origin;
    var issuer = origin;
    for (final p in [
      '$origin/.well-known/oauth-protected-resource${u.path}',
      '$origin/.well-known/oauth-protected-resource'
    ]) {
      try {
        final pr = await _json(p);
        final a = pr['authorization_servers'];
        if (a is List && a.isNotEmpty) {
          issuer = a.first.toString().replaceAll(RegExp(r'/+$'), '');
          break;
        }
      } catch (_) {}
    }
    Map<String, dynamic> meta;
    try {
      meta = await _json('$issuer/.well-known/oauth-authorization-server');
    } catch (_) {
      meta = await _json('$issuer/.well-known/openid-configuration');
    }
    final authEp = meta['authorization_endpoint'] as String;
    final tokenEp = meta['token_endpoint'] as String;
    final regEp = meta['registration_endpoint'];
    if (regEp == null) {
      throw Exception(
          'This server does not allow automatic registration. Use a personal access token instead.');
    }
    final reg = await http.post(Uri.parse(regEp),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'client_name': 'Lumora',
          'redirect_uris': [redirect],
          'grant_types': ['authorization_code', 'refresh_token'],
          'response_types': ['code'],
          'token_endpoint_auth_method': 'none',
        }));
    if (reg.statusCode >= 300) {
      throw Exception('Client registration failed (HTTP ${reg.statusCode}).');
    }
    final clientId = jsonDecode(reg.body)['client_id'] as String;

    final verifier = _rand(48);
    final challenge = base64UrlEncode(sha256.convert(utf8.encode(verifier)).bytes)
        .replaceAll('=', '');
    final state = _rand(16);
    final a = Uri.parse(authEp);
    final authUrl = a.replace(queryParameters: {
      ...a.queryParameters,
      'response_type': 'code',
      'client_id': clientId,
      'redirect_uri': redirect,
      'code_challenge': challenge,
      'code_challenge_method': 'S256',
      'state': state,
    });
    final result = await FlutterWebAuth2.authenticate(
        url: authUrl.toString(), callbackUrlScheme: 'lumora');
    final cb = Uri.parse(result);
    if (cb.queryParameters['state'] != state) {
      throw Exception('Login check failed (state mismatch).');
    }
    final code = cb.queryParameters['code'];
    if (code == null) {
      throw Exception(cb.queryParameters['error'] ?? 'Login cancelled.');
    }
    final tr = await http.post(Uri.parse(tokenEp), headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }, body: {
      'grant_type': 'authorization_code',
      'code': code,
      'redirect_uri': redirect,
      'client_id': clientId,
      'code_verifier': verifier,
    });
    if (tr.statusCode != 200) throw Exception('Token request failed: ${tr.body}');
    return _pack(jsonDecode(tr.body), tokenEp, clientId);
  }

  /// A valid token for a saved server: OAuth (auto-refresh) or the pasted token.
  static Future<String> token(Map s) async {
    final o = s['oauth'] as Map?;
    if (o == null) return (s['token'] ?? '').toString();
    if (DateTime.now().millisecondsSinceEpoch ~/ 1000 < (o['exp'] as int)) {
      return o['access'].toString();
    }
    if (o['refresh'] == null) {
      throw Exception('Login expired. Tap Sign in again in Connectors.');
    }
    final tr = await http.post(Uri.parse(o['tokenEp']), headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }, body: {
      'grant_type': 'refresh_token',
      'refresh_token': o['refresh'],
      'client_id': o['cid'],
    });
    if (tr.statusCode != 200) {
      throw Exception('Login expired. Tap Sign in again in Connectors.');
    }
    final n = _pack(jsonDecode(tr.body), o['tokenEp'], o['cid'], o['refresh']);
    s['oauth'] = n;
    await Store.save();
    return n['access'].toString();
  }
}
