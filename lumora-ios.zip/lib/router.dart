/// Local "Auto" model router: classifies the task, scores every model the key offers,
/// and returns the best ranked list plus a suitable thinking effort. No extra API call.
class Task {
  final String kind; // chat, code, reasoning, writing
  final int cx; // 0 simple, 1 moderate, 2 complex
  final bool vision, tools;
  Task(this.kind, this.cx, this.vision, this.tools);
}

class Prof {
  final double power, speed, code;
  final bool reason, vision;
  Prof(this.power, this.speed, this.reason, this.vision, this.code);
}

class Pick {
  final List<String> order;
  final String? effort;
  final String why;
  Pick(this.order, this.effort, this.why);
}

class AutoRouter {
  static final _skip = RegExp(
      r'embed|whisper|tts|dall|imagen|image|moderation|rerank|audio|transcribe|realtime|video|sora|veo|flux|diffusion|midjourney|guard|ocr',
      caseSensitive: false);
  static bool usable(String m) => !_skip.hasMatch(m);

  static const routerPrompt =
      'You are a model router. Choose the single best model from the given list for the user\'s task. '
      'Weigh capability for the task type, speed and cost: small fast models for simple tasks, the strongest models for hard reasoning, '
      'coding, long or high-stakes tasks, and vision-capable models when an image is attached. '
      'Use your own knowledge of each model\'s strengths; newer generations are usually better. '
      'Reply with ONLY compact JSON: {"model":"<exact id from the list>","effort":"low|medium|high|none","reason":"max 8 words"}. '
      'effort applies only to reasoning-capable models, otherwise none.';

  /// Fast, non-reasoning model used to make the routing decision.
  static String? routerModel(List<String> models, Map<String, int> bad) {
    final now = DateTime.now().millisecondsSinceEpoch;
    String? best;
    var bs = -1e9;
    for (final m in models.where(usable)) {
      final p = profile(m);
      var s = p.speed - (p.reason ? 25 : 0) + (p.power > 55 ? 5 : 0);
      final b = bad[m];
      if (b != null && now - b < 600000) s -= 100;
      if (s > bs) {
        bs = s;
        best = m;
      }
    }
    return best;
  }

  static Task classify(String t, String mode, bool tools, bool vision) {
    final s = t.toLowerCase();
    final code = mode == 'Code' ||
        RegExp(r'```|\b(function|class|bug|error|exception|compile|python|javascript|dart|flutter|sql|regex|api|json|script|code|debug|stack trace|html|css)\b|কোড|প্রোগ্রাম|এরর')
            .hasMatch(s);
    final reason = RegExp(
            r'\b(prove|solve|calculate|equation|derive|analy[sz]e|strategy|optimi[sz]e|why|compare|trade-?off|step by step|plan|algorithm|probability|math)\b|হিসাব|বিশ্লেষণ|সমাধান|কেন|পরিকল্পনা')
        .hasMatch(s);
    final write = RegExp(
            r'\b(write|essay|story|article|email|letter|poem|blog|rewrite|summari[sz]e|translate)\b|লেখ|গল্প|প্রবন্ধ|অনুবাদ|সারাংশ|চিঠি')
        .hasMatch(s);
    var cx = t.length < 120 ? 0 : (t.length < 600 ? 1 : 2);
    if (reason || mode == 'Agent') cx = cx >= 2 ? 2 : cx + 1;
    if ((code || tools || t.contains('\n---\n')) && cx < 1) cx = 1;
    final kind = code ? 'code' : (reason ? 'reasoning' : (write ? 'writing' : 'chat'));
    return Task(kind, cx, vision, tools);
  }

  static Prof profile(String id) {
    final m = id.toLowerCase();
    bool has(String x) => m.contains(x);
    double p = 60, s = 60, code = 0;
    bool r = false, v = false;
    if (has('opus')) {
      p = 96; s = 30; r = true; v = true; code = 8;
    } else if (has('fable') || has('mythos')) {
      p = 98; s = 30; r = true; v = true; code = 10;
    } else if (has('sonnet')) {
      p = 88; s = 55; r = true; v = true; code = 10;
    } else if (has('haiku')) {
      p = 62; s = 92; v = true; code = 3;
    } else if (RegExp(r'gpt-5.*nano').hasMatch(m)) {
      p = 55; s = 96; r = true; v = true;
    } else if (RegExp(r'gpt-5.*mini').hasMatch(m)) {
      p = 76; s = 78; r = true; v = true; code = 5;
    } else if (has('gpt-5')) {
      p = 93; s = 40; r = true; v = true; code = 9;
    } else if (RegExp(r'(^|[^a-z])o[134]([^0-9]|$)').hasMatch(m)) {
      p = 90; s = 25; r = true; v = !has('mini'); code = 8;
    } else if (has('gpt-4.1') || has('gpt-4o')) {
      p = has('mini') ? 68 : 80; s = has('mini') ? 88 : 68; v = true; code = 5;
    } else if (has('gemini')) {
      if (has('lite')) {
        p = 55; s = 95; v = true;
      } else if (has('flash')) {
        p = 72; s = 88; v = true; r = true; code = 4;
      } else if (has('pro')) {
        p = 90; s = 45; v = true; r = true; code = 8;
      } else {
        p = 70; s = 70; v = true;
      }
    } else if (has('deepseek')) {
      if (has('r1') || has('reasoner')) {
        p = 86; s = 30; r = true; code = 8;
      } else {
        p = 78; s = 65; code = 7;
      }
    } else if (has('qwen')) {
      p = (has('max') || has('235') || has('72b')) ? 80 : 66;
      s = 60; code = has('coder') ? 9 : 4; v = has('vl');
    } else if (has('llama') || has('mistral') || has('mixtral') || has('grok')) {
      p = (has('70b') || has('405b') || has('large') || has('grok')) ? 76 : 58;
      s = 65; code = 4;
    } else if (has('mini') || has('lite') || has('small') || has('nano') || has('turbo') || has('fast')) {
      p = 58; s = 90;
    } else if (has('pro') || has('large') || has('max') || has('ultra')) {
      p = 80; s = 45;
    }
    if (has('codex') || has('coder')) code += 10;
    if (has('thinking')) r = true;
    double ver = 0;
    for (final mm in RegExp(r'(?<!\d)(\d)(?:[.\-_](\d))?(?!\d)').allMatches(m)) {
      final d = double.parse('${mm.group(1)}.${mm.group(2) ?? 0}');
      if (d > ver) ver = d;
    }
    p += (ver > 10 ? 10.0 : ver) * 1.2;
    return Prof(p, s, r, v, code);
  }

  static Pick pick(List<String> models, Task k, Map<String, int> bad) {
    final now = DateTime.now().millisecondsSinceEpoch;
    var c = models.where(usable).toList();
    if (c.isEmpty) c = List.of(models);
    if (k.vision) {
      final v = c.where((m) => profile(m).vision).toList();
      if (v.isNotEmpty) c = v;
    }
    double score(String m) {
      final p = profile(m);
      final w = [0.25, 0.55, 0.8][k.cx];
      var sc = p.power * w + p.speed * (1 - w);
      if (k.kind == 'code') sc += p.code;
      if ((k.kind == 'reasoning' || k.cx == 2) && p.reason) sc += 8;
      if (k.tools && (m.toLowerCase().contains('r1') || m.toLowerCase().contains('reasoner'))) sc -= 15;
      if (k.cx == 0 && p.reason && p.speed < 50) sc -= 10;
      final b = bad[m];
      if (b != null && now - b < 600000) sc -= 60;
      return sc;
    }

    c.sort((a, b) => score(b).compareTo(score(a)));
    final pr = profile(c.first);
    final effort = pr.reason ? ['low', 'medium', 'high'][k.cx] : null;
    return Pick(c, effort, '${k.kind} · ${['simple', 'moderate', 'complex'][k.cx]}');
  }
}
